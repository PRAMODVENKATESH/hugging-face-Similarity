from .main import LinkifyIt  # noqa: F401p
from .main import SchemaError  # noqa: F401p

__version__ = "1.0.3"
